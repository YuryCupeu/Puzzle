package com.ubl.puzzle;

import android.content.Context;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.ViewTreeObserver;
import android.widget.Button;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Random;

public class MainActivity3 extends AppCompatActivity {

    private static final int columns = 3;
    private static final int dimensions = columns * columns;

    private static String[] tiles;

    private static GestureDetectGridView mGridView;

    private static int mColumnWidth, mColumnHeight;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);

        init();
        scramble();
        setDimensions();
    }

    private void setDimensions() {
        ViewTreeObserver vto = mGridView.getViewTreeObserver();
        vto.addOnGlobalLayoutListener(new ViewTreeObserver.OnGlobalLayoutListener(){
            @Override
            public void onGlobalLayout(){
                mGridView.getViewTreeObserver().removeOnGlobalLayoutListener(this);
                int displayWidth = mGridView.getMeasuredWidth();
                int displayHeight = mGridView.getMeasuredHeight();

                int statusbarHeight = getStatusBarHeight(getApplicationContext());
                int requiredHeight = displayHeight - statusbarHeight;

                mColumnWidth = displayWidth/columns;
                mColumnHeight = requiredHeight/columns;

                display(getApplicationContext());
            }
        });
    }

    private int getStatusBarHeight(Context context){
        int result = 0;
        int resourceId = context.getResources().getIdentifier("status_bar_height", "dimen", "android");

        if(resourceId > 0){
            result = context.getResources().getDimensionPixelSize(resourceId);
        }
        return result;
    }

    private static void display(Context context)
    {
        ArrayList<Button> buttons = new ArrayList<>();
        Button button;

        for(int i = 0; i < tiles.length; i++)
        {
            button = new Button(context);

            if(tiles[i].equals("0"))
                button.setBackgroundResource(R.drawable.skull1);
            else if(tiles[i].equals("1"))
                button.setBackgroundResource(R.drawable.skull2);
            else if(tiles[i].equals("2"))
                button.setBackgroundResource(R.drawable.skull3);
            else if(tiles[i].equals("3"))
                button.setBackgroundResource(R.drawable.skull4);
            else if(tiles[i].equals("4"))
                button.setBackgroundResource(R.drawable.skull5);
            else if(tiles[i].equals("5"))
                button.setBackgroundResource(R.drawable.skull6);
            else if(tiles[i].equals("6"))
                button.setBackgroundResource(R.drawable.skull7);
            else if(tiles[i].equals("7"))
                button.setBackgroundResource(R.drawable.skull8);
            else if(tiles[i].equals("8"))
                button.setBackgroundResource(R.drawable.skull9);

            buttons.add(button);
        }
        mGridView.setAdapter(new CustomAdapter(buttons, mColumnWidth, mColumnHeight));

    }

    private void scramble()
    {
        int index;
        String temp;
        Random random = new Random();

        for(int i = tiles.length - 1; i > 0; i--)
        {
            index = random.nextInt(i + 1);
            temp = tiles[index];
            tiles[index] = tiles[i];
            tiles[i] = temp;
        }
    }

    private void init()
    {
        mGridView = (GestureDetectGridView) findViewById(R.id.grid);
        mGridView.setNumColumns(columns);
        tiles = new String[dimensions];
        for(int i = 0; i < dimensions; i++)
        {
            tiles[i] = String.valueOf(i);
        }
    }

    public static void swap(Context context, int position, int swap)
    {
        String newposition = tiles[position + swap];
        tiles[position + swap] = tiles[position];
        tiles[position] = newposition;
        display(context);

        if (isSolved())
            Toast.makeText(context, "YOU WIN!", Toast.LENGTH_SHORT).show();
    }

    private static boolean isSolved()
    {
        boolean solved = false;

        for (int i = 0; i < tiles.length; i++)
        {
            if (tiles[i].equals(String.valueOf(i)))
                solved = true;
            else
            {
                solved = false;
                break;
            }
        }
        return solved;
    }

    public static void movetiles(Context context, String direction, int position)
    {
        //Upper-left tile
        if (position == 0)
        {
            if (direction.equals("right"))
                swap(context, position, 1);
            else if (direction.equals("down"))
                swap(context, position, columns);
            else
                Toast.makeText(context, "Invalid move", Toast.LENGTH_SHORT).show();
        }
        //Upper-center tile
        else if (position > 0 && position < columns - 1)
        {
            if (direction.equals("left"))
                swap(context, position, -1);
            else if (direction.equals("down"))
                swap(context, position, columns);
            else if (direction.equals("right"))
                swap(context, position, 1);
            else
                Toast.makeText(context, "Invalid move", Toast.LENGTH_SHORT).show();
        }
        //Upper-right tile
        else if (position > columns - 2 && position < columns)
        {
            if (direction.equals("left"))
                swap(context, position, -1);
            else if (direction.equals("down"))
                swap(context, position, columns);
            else
                Toast.makeText(context, "Invalid move", Toast.LENGTH_SHORT).show();
        }
        //Mid-left tile
        else if (position == columns)
        {
            if (direction.equals("right"))
                swap(context, position, 1);
            else if (direction.equals("down"))
                swap(context, position, columns);
            else if (direction.equals("up"))
                swap(context, position, -columns);
            else
                Toast.makeText(context, "Invalid move", Toast.LENGTH_SHORT).show();
        }
        //Mid-center tile
        else if(position > columns && position < columns + 2)
        {

            if (direction.equals("right"))
                swap(context, position, 1);
            else if (direction.equals("left"))
                swap(context, position, -1);
            else if (direction.equals("down"))
                swap(context, position, columns);
            else if (direction.equals("up"))
                swap(context, position, -columns);
            else
                Toast.makeText(context, "Invalid move", Toast.LENGTH_SHORT).show();
        }
        //Mid-right tile
        else if (position > columns + 1 && position < columns + 3)
        {
            if (direction.equals("left"))
                swap(context, position, -1);
            else if (direction.equals("down"))
                swap(context, position, columns);
            else if (direction.equals("up"))
                swap(context, position, -columns);
            else
                Toast.makeText(context, "Invalid move", Toast.LENGTH_SHORT).show();
        }
        //Bottom-left tile
        else if (position > columns + 2 && position < columns + 4)
        {
            if (direction.equals("right"))
                swap(context, position, 1);
            else if (direction.equals("up"))
                swap(context, position, -columns);
            else
                Toast.makeText(context, "Invalid move", Toast.LENGTH_SHORT).show();
        }
        //Bottom-center tile
        else if (position > columns + 3 && position < columns + 5)
        {
            if (direction.equals("right"))
                swap(context, position, 1);
            else if (direction.equals("left"))
                swap(context, position, -1);
            else if (direction.equals("up"))
                swap(context, position, -columns);
            else
                Toast.makeText(context, "Invalid move", Toast.LENGTH_SHORT).show();
        }
        //Bottom-right tile
        else
        {
            if (direction.equals("left"))
                swap(context, position, -1);
            else if (direction.equals("up"))
                swap(context, position, -columns);
            else
                Toast.makeText(context, "Invalid move", Toast.LENGTH_SHORT).show();
        }
    }
}
